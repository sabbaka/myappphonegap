angular.module('myApp', [])

angular.module('myApp').controller('mainController', function($scope, $window) {
    $scope.mapshow = true;
    $scope.map = function() {
//        $scope.template = 'map.html';
        $scope.mapshow = true;
        $scope.template = '';
    }

    $scope.settings = function() {
        $scope.mapshow = false;
        $scope.template = 'settings.html';
    }

    $scope.order = function() {
        $scope.mapshow = false;
        $scope.template = 'order.html';
    }

    $scope.user = function() {
        $scope.mapshow = false;
        $scope.template = 'user.html';
    }

    $scope.adv = function() {
        $scope.mapshow = false;
        $scope.template = 'adv.html';
    }

    $scope.mapWidth = $window.innerWidth;
    $scope.mapHeight = $window.innerHeight;
});